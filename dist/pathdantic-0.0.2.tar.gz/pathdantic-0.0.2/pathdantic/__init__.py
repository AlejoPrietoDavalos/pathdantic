from pathdantic.base import BasePath, BasePathStatic, BasePathDinamic
from pathdantic.folder import PathFolderStatic