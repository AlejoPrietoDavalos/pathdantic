from pathdantic.folder import PathFolderStatic
from pathdantic.root import PathRoot